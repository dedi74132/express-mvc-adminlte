const express = require("express")
const router = express.Router()
const datacoronaController = require("../controller/datacoronaController")

router.get("/", datacoronaController.index)
router.get("/create", datacoronaController.create)
router.post("/", datacoronaController.store)
router.get("/:id/edit", datacoronaController.edit)
router.put("/:id", datacoronaController.update)
router.delete("/:id", datacoronaController.destroy)
module.exports = router
