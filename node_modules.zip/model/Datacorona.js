module.exports = {
  get: function (con, callback) {
    con.query("SELECT * FROM datacorona", callback)
  },

  getById: function (con, id, callback) {
    con.query(`SELECT * FROM datacorona WHERE id = ${id}`, callback)
  },

  create: function (con, data, callback) {
    con.query(
      `INSERT INTO datacorona SET 
      hari = '${data.hari}', 
      jumlah_meninggal = '${data.jumlah_meniggal}', 
      jumlah_positif = '${data.jumlah_positif}'`,
      callback
    )
  },

  update: function (con, data, id, callback) {
    con.query(
      `UPDATE datacorona SET 
      hari = '${data.hari}', 
      jumlah_meninggal = '${data.jumlah_meniggal}', 
      jumlah_positif = '${data.jumlah_positif}',
      WHERE id = ${id}`,
      callback
    )
  },

  destroy: function (con, id, callback) {
    con.query(`DELETE FROM datacorona WHERE id = ${id}`, callback)
  }
}
