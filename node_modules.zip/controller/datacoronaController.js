const Datacorona = require("../model/Datacorona")

module.exports = {
  index: function (req, res) {
    Datacorona.get(req.con, function (err, rows) {
      res.render("layouts.index", { data: rows, page: "pages/datacorona/index" })
    })
  },

  create: function (req, res) {
    res.render("datacorona/create")
  },

  store: function (req, res) {
    Datacorona.create(req.con, req.body, function (err) {
      res.redirect("/datacorona")
    })
  },

  edit: function (req, res) {
    Datacorona.getById(req.con, req.params.id, function (err, rows) {
      res.render("datacorona/edit", { data: rows[0] })
    })
  },

  update: function (req, res) {
    Datacorona.update(req.con, req.body, req.params.id, function (err) {
      res.redirect("/datacorona")
    })
  },

  destroy: function (req, res) {
    Datacorona.destroy(req.con, req.params.id, function (err) {
      res.redirect("/datacorona")
    })
  }
}
